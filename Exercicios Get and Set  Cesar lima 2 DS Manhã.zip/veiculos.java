package GetAndSet;

public class veiculos {
	String manete;
	String volante;
	String retrovisor;
	
	public veiculos (String manete,String volante, String retrovisor){
		this.manete = manete;
		this.volante = volante;
		this.retrovisor = retrovisor;
}
	
	public String getManete(){
		return manete;
	}

	public void setManete (String manete){
		this.manete = manete;
	}
	
	public String getVolante(){
		return volante;
		
	}
	public void setVolante (String volante){
		this.volante = volante;
	}
	
	public String getRetrovisoR(){
		return retrovisor;
	}
	public void setRetrovisor (String retrovisor){
		this.retrovisor = retrovisor;
	}
	
	public void apresentarPecas(){
		System.out.println("Pre�o do manete: R$ " + this.getManete());
	
		System.out.println("Pre�o do volante: R$ " + this.getVolante());
	
		System.out.println("Pre�o do retrovisor: R$ " + this.getRetrovisoR());
	
	}
}
