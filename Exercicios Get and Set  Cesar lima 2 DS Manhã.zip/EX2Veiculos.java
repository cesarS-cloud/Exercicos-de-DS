package GetAndSet;
import java.util.Scanner;
public class EX2Veiculos {

	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		moto Moto = new moto("Yamaha","NMax","vermelha");
		Moto.apresentarMoto();
		
		
		System.out.println("______________________");
	
		caminhao Caminhao = new caminhao("Iveco","Stralis","Azul");
		Caminhao.apresentarCaminhao();

		System.out.println("______________________");
		
		carro Carro = new carro("Range Rover","Evoque","Bordo");
		Carro.apresentarCarro();
		
		System.out.println("______________________");
		
		veiculos Pe�as = new veiculos("80","90","40");
		Pe�as.apresentarPecas();
		
	}

}
