package GetAndSet;

public class Pessoa {
	private String nome;
	private String endereco;
	private String telefone;
	private String email;
	private String RG;
	
	
public Pessoa (String nome, String endereco, String telefone, String email , String RG){
	this.nome = nome;
	this.endereco = endereco;
	this.telefone = telefone;
	this.email = email;
	this.RG = RG;
	}

	public String getNome(){
		return nome;
	}

	public void setNome (String nome){
		this.nome = nome;
	}
	
	public String getEndereco(){
		return endereco;
	}

	public void setEndereco (String endereco){
		this.endereco = endereco;
	}

	public String getTelefone(){
		return telefone;
	}
	public void setTelefone(String telefone){
		this.telefone = telefone;
	}
	public String getEmail(){
		return email;
	}
	public void setEmail (String email){
		this.email = email;
	}
	public String getRG (){
		return RG;
	}
	public void setRG (String RG){
		this.RG = RG;
					
	}
	
	public void apresentaPessoa(){
		System.out.println("Nome: " + this.getNome());
		System.out.println("Endere�o: " + this.getEndereco());
		System.out.println("Telefone: " + this.getTelefone());
		System.out.println("Email: " + this.getEmail());
		System.out.println("RG: " + this.getRG());
	}
}
