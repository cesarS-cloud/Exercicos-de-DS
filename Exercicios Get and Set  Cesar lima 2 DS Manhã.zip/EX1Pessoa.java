package GetAndSet;

public class EX1Pessoa {

	public static void main(String[] args) {
		Pessoa p = new Pessoa("cesar","etec","982346830","cesarlima387@gmail.com","389513477");
		
		p.apresentaPessoa();
		
	}
		
	}


