package Exercicios;

import java.util.Scanner;

public class EX2Funcionario {

	public static void main(String[] args) {
		
 double aumento;		
		Scanner in = new Scanner (System.in);
		funcionario f1 = new funcionario();
		
		f1.nome = "josepicudo";
		f1.salarioBruto = 1000;
		f1.aumentoSalario(10);
		System.out.println("voce teve um aumento de:" + f1.aumentoSalario);
		f1.salarioLiquido(1000, 10);
		System.out.println(f1.salarioLiquido);
		
		
	}

}
