package Exercicios;

public class idade {

	int Idade;	
	String nome;
	String sobrenome;

	 int Idade(int anoAtual, int anoNascimento ) {
		 Idade = anoAtual - anoNascimento;
		 return Idade;
		 

	}
}
