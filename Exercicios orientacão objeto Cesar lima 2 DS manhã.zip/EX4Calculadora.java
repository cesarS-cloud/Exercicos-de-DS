package Exercicios;

public class EX4Calculadora {

	public static void main(String[] args) {
		calculadora calculadora = new calculadora();
		
		calculadora.adi��o(10, 20);
		
		System.out.println("a adi��o �: " + calculadora.adi��o);

		System.out.println("_________________________");
		calculadora.subtra��o(15, 10);
		
		System.out.println("a subtra��o �: " + calculadora.subtra��o);
		
		System.out.println("_________________________");
		calculadora.multiplica��o(10, 3);
		
		System.out.println("a multiplica��o �: " + calculadora.multiplica��o);
		
		System.out.println("_________________________");
		calculadora.divis�o(100, 4);
		
		System.out.println("a divis�o �: " + calculadora.divis�o);
		System.out.println("_________________________");
				
	}

}
