package Exercicios;

public class quadrados {
	double base;
	double altura;
	double area;
	
	void calcularArea (double base, double altura){ // Calcular �rea, m�todo com par�metro sem retorno
		area = base * altura;
	}
	
	double apresentarArea (){ // Apresentar �rea, m�todo sem par�metro com retorno
		return area;
	}
}
