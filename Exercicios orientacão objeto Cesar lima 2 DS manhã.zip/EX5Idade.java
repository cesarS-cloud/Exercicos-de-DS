package Exercicios;

public class EX5Idade {

	public static void main(String[] args) {
		
		idade id = new idade();
		idade Nome = new idade();
		idade Sobrenome = new idade();
		
		id.Idade(2020, 2003);
		
		Nome.nome = "cesar" ;
		Sobrenome.sobrenome = "sousa lima" ;
		
		System.out.println("idade �: " + id.Idade );
				
		System.out.println(" seu nome completo � : "+ Nome.nome + " " + Sobrenome.sobrenome);
	}

}
