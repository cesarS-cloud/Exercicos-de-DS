package Exercicios;

public class Trianguloeretangulo {

	public static void main(String[] args) {
		 triangulo Triangulo = new triangulo();
		 retangulo Retangulo = new retangulo();
		 
		 
		 Triangulo.calcularArea(13, 6);
		 Retangulo.calcularArea(12,7);
		 
		 System.out.println("�rea do Triangulo = "+Triangulo.apresentarArea());
		 System.out.println("�rea do Retangulo = "+Retangulo.apresentarArea());

	}

}
