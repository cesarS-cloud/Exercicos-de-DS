package Exercicios;

public class funcionario {
	String nome;
	double salarioBruto;
	double imposto;
	double salarioLiquido;
	double aumentoSalario;
	
	
		double salarioLiquido (double salarioBruto, double imposto) {
			salarioLiquido = salarioBruto - (salarioBruto*imposto/100);
		return salarioLiquido;
		}			
		
	double aumentoSalario (double aumento) {
		salarioBruto = salarioBruto + ( salarioBruto * aumento/100);
		return salarioBruto;
	}
		
	}



