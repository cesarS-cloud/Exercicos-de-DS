package Exercicios;

public class retangulo {
	
	double base;
	double altura;
	double area;
	
	void calcularArea (double base, double altura){ 
		area = base * altura;
	}
	
	double apresentarArea (){ 
		return area;
	}
	
}

