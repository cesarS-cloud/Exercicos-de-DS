package Exercicios;

public class triangulo {
		
	double base;
	double altura;
	double area;
	
	void calcularArea (double base, double altura){ 
		area = base * altura/2;
	}
	
	double apresentarArea (){ 
		return area;
	}
	
}