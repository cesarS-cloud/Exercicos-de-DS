package Exercicios;

public class EX1Quadrados {

	public static void main(String[] args) {
		
		//Leitura dos m�todos
		quadrados quadrado1 = new quadrados();
		quadrados quadrado2 = new quadrados();
		
		//Atribui��o dos valores
		quadrado1.calcularArea(13, 6);
		quadrado2.calcularArea(25, 10);
		
		//Apresenta��o das �reas
		System.out.println("�rea do quadrado 1 = "+quadrado1.apresentarArea());
		System.out.println("�rea do quadrado 2 = "+quadrado2.apresentarArea());
	}


	}


